Emmet Hoversten - hover114

Compile and run:
1. javac FractalDrawer.java
2. java FractalDrawer
3. input shape for fractal

MAKE SURE TO SLIGHTLY RESIZE WINDOW TO SEE FULL FRACTAL

I did utilize a shapeColors[] list in my fractal drawer to cycle through colors as I go deeper each level of a fractal and index the array with the # of level I'm on

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.

Emmet Hoversten